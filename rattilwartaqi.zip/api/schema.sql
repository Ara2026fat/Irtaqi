-- ارتقِ — بنيةُ قاعدةِ البيانات (D1)
-- ══════════════════════════════════════
-- قاعدةٌ أولى: ليس في هذه الجداولِ شيءٌ يَدلُّ على شخص. لا اسمَ ولا بريدَ ولا جوالَ ولا موقعَ دقيق،
-- ولا محتوى حفظٍ مقروءًا للخادم. و«المعرّف» رقمٌ عشوائيٌّ يولّده الجهازُ ويَمسحه متى شاء.
-- التنفيذ:  npx wrangler d1 execute irtaqi-db --remote --file=api/schema.sql

-- ١) عدُّ الأجهزةِ المجهول: مَن استعملَ التطبيقَ ومتى آخرَ مرّة. كتابةٌ واحدةٌ في اليومِ للجهاز.
CREATE TABLE IF NOT EXISTS devices (
  id         TEXT PRIMARY KEY,         -- /^[A-Za-z0-9_-]{16,64}$/ يولّده الجهاز
  first_day  TEXT NOT NULL,            -- YYYY-MM-DD بتوقيتِ UTC (عليه تُصفَّر حدودُ الطبقةِ المجّانيّة)
  last_day   TEXT NOT NULL,
  ver        TEXT,                     -- نسخةُ التطبيقِ كما أرسلَها، مقطوعةٌ عند ٤٠ محرفًا
  country    TEXT                      -- رمزُ الدولةِ من ترويسةِ Cloudflare لا من التطبيق
);
-- الفهرسُ لأجلِ /api/stats: «النشِطون اليومَ / ٧ / ٣٠». وهو كتابةُ صفٍّ إضافيّةٍ عند تحديثِ last_day،
-- ولذلك لا نُحدّث الصفَّ إلّا مرّةً واحدةً في اليوم (انظر /api/ping في worker.js).
CREATE INDEX IF NOT EXISTS idx_devices_last ON devices(last_day);

-- ٢) النسخةُ المُعمّاة. الخادمُ لا يَفكُّ blob ولا يَقدر: المفتاحُ عند صاحبِه وحدَه (AES-GCM).
-- يُخزَّن كما وصلَ، نصًّا، بلا تحليلٍ ولا افتراضِ JSON.
CREATE TABLE IF NOT EXISTS blobs (
  id       TEXT PRIMARY KEY,
  rev      INTEGER NOT NULL DEFAULT 0, -- عدّادٌ متزايدٌ للتزامنِ المتفائل؛ الخادمُ وحدَه يُزيده
  blob     TEXT NOT NULL,              -- سقفُه ١٬٥٠٠٬٠٠٠ بايتًا (حدُّ D1 للصفِّ ٢٬٠٠٠٬٠٠٠)
  updated  INTEGER NOT NULL,           -- epoch ms، لمعرفةِ الراكدِ عند التنظيف
  kh       TEXT                        -- بصمةُ SHA-256 لمفتاحِ الجهازِ (اختياريّ) — لا المفتاحُ نفسُه
);
-- لا فهرسَ ثانويًّا هنا بقصد: الاستعلامُ كلُّه على المفتاحِ الأساسيّ، وفهرسٌ على `updated`
-- يُكلّف كتابةَ صفٍّ إضافيّةٍ في كلِّ مزامنةٍ — والكتابةُ أندرُ ما في الطبقةِ المجّانيّة
-- (١٠٠٬٠٠٠ صفٍّ في اليوم). وتنظيفُ الراكدِ عملٌ نادرٌ يَكفيه مسحٌ كاملٌ (القراءةُ أرخصُ خمسينَ ضعفًا).

-- ٣) تذكيرُ الوِرد. لا حمولةَ في الإشعارِ فلا نَحتاج مفاتيحَ الاشتراك (p256dh/auth): العنوانُ يَكفي.
CREATE TABLE IF NOT EXISTS subs (
  id         TEXT PRIMARY KEY,
  endpoint   TEXT NOT NULL,            -- عنوانُ خدمةِ الدفعِ في المتصفّح
  tz         TEXT NOT NULL,            -- اسمُ المنطقةِ (IANA) ليَكون التذكيرُ بتوقيتِ الجهازِ هو
  h          INTEGER NOT NULL,         -- ٠..٢٣
  m          INTEGER NOT NULL,         -- ٠..٥٩
  next_at    INTEGER NOT NULL,         -- epoch ms: لحظةُ الإيقاظِ القادمة، تُحسب عند الاشتراكِ وبعد كلِّ إرسال
  last_sent  INTEGER NOT NULL DEFAULT 0,
  kh         TEXT
);
-- هذا الفهرسُ هو مِفصلُ الاقتصادِ كلِّه: المهمّةُ المجدوَلةُ تَسأل «مَن حان وِردُه؟» في كلِّ دقيقة،
-- فبه تَقرأ صفوفَ المستحقّين وحدَهم (صفرًا في معظمِ الدقائق) لا الجدولَ كلَّه ١٤٤٠ مرّةً في اليوم.
CREATE INDEX IF NOT EXISTS idx_subs_next ON subs(next_at);

-- ٤) الأسرار: STATS_KEY ، VAPID_PUBLIC ، VAPID_PRIVATE_JWK.
-- مفاتيحُ VAPID يولّدها العاملُ بنفسِه عند أوّلِ حاجةٍ ويَحفظها هنا، والخاصُّ لا يَخرج في استجابة.
-- ويَسبق أيَّ قيمةٍ هنا متغيّرُ بيئةٍ بالاسمِ نفسِه إن وُجد.
CREATE TABLE IF NOT EXISTS cfg (k TEXT PRIMARY KEY, v TEXT NOT NULL);

-- ٥) عدّادُ المعرّفاتِ الجديدةِ في اليوم: سدٌّ في وجهِ مَن يُغرق القاعدةَ بمعرّفاتٍ مُختلَقة.
-- كتابةٌ واحدةٌ لكلِّ معرّفٍ جديدٍ لا لكلِّ طلب.
CREATE TABLE IF NOT EXISTS ctr (d TEXT PRIMARY KEY, n INTEGER NOT NULL DEFAULT 0);

-- ════════════════════════════════════════════════════════════════
-- ‫الاقتراحات: صوتُهم يَصل ولا تَصل أسماؤهم.
-- ‫لا عمودَ لمعرِّفِ جهازٍ ولا لعنوانِ شبكةٍ — **عمدًا وليس سهوًا**.
-- ‫فلا يُجمَع اقتراحُ شخصٍ إلى أخيه، ولا يُعرَف متى يَفتح التطبيق.
-- ‫و‎contact‎ يَكتبه صاحبُه باختياره أو يَتركه فارغًا.
-- ════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS notes (
  rid     INTEGER PRIMARY KEY AUTOINCREMENT,
  at      INTEGER NOT NULL,
  ver     TEXT,
  dar     TEXT,
  text    TEXT NOT NULL,
  contact TEXT,
  seen    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS notes_at ON notes(seen, at DESC);

-- ‫عدُّ الدور: كم جهازًا يَحمل كلَّ رمز، لا مَن هم.
CREATE TABLE IF NOT EXISTS dars (
  code TEXT PRIMARY KEY,
  name TEXT,
  goal TEXT,
  exam_at TEXT
);
